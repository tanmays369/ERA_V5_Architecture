"""Pre-handover adversarial gates; malformed inputs must fail without a traceback."""
import pathlib,sys,tempfile,unittest,json,copy
import yaml
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'harness'))
from check_config import load_config
from source_audit import audit_text
BASE=ROOT/'configs/config_v0.yaml';TINY=ROOT/'configs/tiny_moe.yaml'
class SignoffTests(unittest.TestCase):
 def modified(self,path,value,open_mode=False):
  obj=yaml.safe_load((BASE if open_mode else TINY).read_text());node=obj
  for key in path.split('.')[:-1]:node=node.setdefault(key,{})
  node[path.split('.')[-1]]=value
  text='\n'.join(line+' # source: G5-signoff-adversarial-test' for line in yaml.safe_dump(obj,sort_keys=False).splitlines())
  with tempfile.TemporaryDirectory() as tmp:
   p=pathlib.Path(tmp)/'case.yaml';p.write_text(text)
   return load_config(p if open_mode else BASE,None if open_mode else p,allow_open=open_mode)[1]
 def test_parent_source_enforced(self):
  text=BASE.read_text().replace('model:  # source: G5 master schema grouping of the sourced settings below','model:')
  with tempfile.TemporaryDirectory() as tmp:
   p=pathlib.Path(tmp)/'bad.yaml';p.write_text(text);self.assertTrue(any('model: MISSING_SOURCE' in e for e in load_config(p,allow_open=True)[1]))
 def test_vague_source_rejected(self):
  self.assertIn('VAGUE_SOURCE',audit_text('x: 1 # source: default')[0]['issues'])
 def test_wrong_scalar_types(self):
  for key,value in [('attention.query_heads','three'),('attention.kv_heads',False),('moe.n_group',0),('evaluation.eval_batches',True),('model.norm_eps','small'),('data_curriculum.domain_labels',[]),('data_curriculum.stage_1_warmup.mixture_weights',['bad'])]:
   with self.subTest(key=key):self.assertTrue(self.modified(key,value))
 def test_ep_divisibility(self):self.assertTrue(self.modified('distributed.ep_size',3))
 def test_partial_open_config_still_checks_known_dimensions(self):
  self.assertTrue(self.modified('attention.kv_heads',0,True))
 def test_pending_sizes_never_suspend_independent_controls(self):
  for key,value in [('data.mode','unknown'),('explainability.tap_every_steps',0),('explainability.sae_probe.top_k',100),('explainability.sae_probe.kind','invented'),('training.sequence_length',-1)]:
   with self.subTest(key=key):self.assertTrue(self.modified(key,value,True))
 def test_initialization_bounds(self):
  for key,value in [('model.init_std',0),('attention.diff_lambda_param_std',-1),('attention.diff_lambda_decay_rate',-1),('explainability.sae_probe.seed',-1)]:self.assertTrue(self.modified(key,value))
 def test_open_registry_only_size_fields(self):
  fields=json.loads((ROOT/'harness/pending_size_fields.json').read_text());self.assertNotIn('distributed.zero_stage',fields);self.assertEqual(len(fields),34)
 def test_all_shipped_overrides_have_sources_and_validate(self):
  for file in (ROOT/'configs').glob('*.yaml'):
   if file==BASE:continue
   with self.subTest(file=file.name):self.assertEqual(load_config(BASE,file)[1],[])
 def test_override_all_leaves_are_known(self):
  known=set(json.loads((ROOT/'harness/schema_fields.json').read_text()));self.assertTrue({r['setting'] for r in audit_text(TINY.read_text())}<=known)
 def test_ke_reference_status_cannot_impersonate_delivered_provider(self):
  import torch
  from model import Model
  c=load_config(BASE,TINY)[0];c['embedding']['ke2']['status']='delivered'
  with self.assertRaisesRegex(ValueError,'explicit embedding_provider'):Model(c,ROOT/'assets/tokenizer.json')
if __name__=='__main__':unittest.main()
