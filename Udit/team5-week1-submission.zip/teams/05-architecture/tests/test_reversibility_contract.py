"""Reversibility is a validated contract, never a silent runtime fallback."""
import copy,json,os,pathlib,subprocess,sys,tempfile,unittest
os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
import torch,yaml
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'harness'))
from check_config import load_config
from model import Model
BASE=ROOT/'configs/config_v0.yaml';TINY=ROOT/'configs/tiny_moe.yaml'


class ReversibilityContractTests(unittest.TestCase):
    def changed(self,updates):
        obj=yaml.safe_load(TINY.read_text());obj['reversibility'].update(updates)
        text=yaml.safe_dump(obj,sort_keys=False)
        text='\n'.join(line+' # source: explicit reversible contract test' for line in text.splitlines())
        return text
    def validate(self,updates):
        with tempfile.TemporaryDirectory() as temp:
            path=pathlib.Path(temp)/'override.yaml';path.write_text(self.changed(updates))
            return load_config(BASE,path)
    def test_default_configs_valid_and_target_explicit(self):
        base,errors=load_config(BASE,allow_open=True);self.assertEqual(errors,[])
        self.assertEqual(base['reversibility']['method'],'midpoint');self.assertFalse(base['reversibility']['enabled'])
        tiny,errors=load_config(BASE,TINY);self.assertEqual(errors,[]);self.assertEqual(tiny['reversibility']['method'],'none')
    def test_unknown_method_rejected(self):self.assertTrue(self.validate({'method':'invented'})[1])
    def test_none_cannot_be_enabled(self):self.assertTrue(self.validate({'method':'none','enabled':True})[1])
    def test_unimplemented_status_cannot_be_claimed(self):self.assertTrue(self.validate({'contract_status':'implemented'})[1])
    def test_segment_bounds(self):
        for size in [0,True,3]:self.assertTrue(self.validate({'segment_layers':size})[1])
    def test_rng_and_controller_replay_required(self):
        for key in ['preserve_rng_state','count_router_updates_once']:self.assertTrue(self.validate({key:False})[1])
    def test_dtype_and_tolerances(self):
        self.assertTrue(self.validate({'reconstruction_dtype':'bf16'})[1])
        for value in [0,-1,float('nan'),.1]:self.assertTrue(self.validate({'reconstruction_rtol':value})[1])
    def test_model_raises_before_loading_assets_if_enabled(self):
        c,errors=self.validate({'enabled':True,'method':'midpoint'});self.assertEqual(errors,[])
        with self.assertRaisesRegex(NotImplementedError,'pending contract'):Model(c,'unused')
    def test_executable_cli_rejects_pending_engine(self):
        with tempfile.TemporaryDirectory() as temp:
            path=pathlib.Path(temp)/'override.yaml';path.write_text(self.changed({'enabled':True,'method':'midpoint'}))
            p=subprocess.run([sys.executable,str(ROOT/'harness/check_config.py'),str(BASE),'--override',str(path),'--require-executable'],capture_output=True,text=True)
            self.assertEqual(p.returncode,1);self.assertIn('no executable inverse/backward',p.stdout)
    def test_new_field_source_is_not_optional(self):
        text=BASE.read_text().replace('  method: "midpoint"  # source: Instructor G6 architecture clarification accepted midpoint; target, not an implemented runtime','  method: "midpoint"')
        with tempfile.TemporaryDirectory() as temp:
            path=pathlib.Path(temp)/'bad.yaml';path.write_text(text)
            self.assertTrue(any('reversibility.method' in e and 'MISSING_SOURCE' in e for e in load_config(path,allow_open=True)[1]))
    def test_disabled_method_choice_has_identical_loss_and_gradients(self):
        torch.set_num_threads(1);torch.manual_seed(1234)
        c,errors=load_config(BASE,TINY);self.assertEqual(errors,[])
        d=copy.deepcopy(c);d['reversibility']['method']='midpoint'
        a,b=Model(c,ROOT/'assets/tokenizer.json'),Model(d,ROOT/'assets/tokenizer.json');b.load_state_dict(a.state_dict())
        ids=torch.tensor([[130725,100,101]]);targets=torch.tensor([[100,101,102]])
        def run(model):
            nll,n,aux,z,lz,_=model(ids,targets)
            loss=nll/n+.01*aux+.001*z+.0001*lz;loss.backward();return loss.detach()
        self.assertTrue(torch.equal(run(a),run(b)))
        for p,q in zip(a.parameters(),b.parameters()):
            if p.grad is None or q.grad is None:self.assertIs(p.grad,q.grad)
            else:self.assertTrue(torch.equal(p.grad,q.grad))

if __name__=='__main__':unittest.main()
