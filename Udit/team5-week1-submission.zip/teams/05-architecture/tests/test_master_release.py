"""Forensic synthesis regressions: reject broken contracts, test adopted code mathematically."""
import copy,json,math,pathlib,subprocess,sys,tempfile,unittest
import os
os.environ["CUBLAS_WORKSPACE_CONFIG"]=":4096:8"
import torch
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'harness'))
from check_config import load_config
from model import MoE
from monitoring import StepMonitor
from input_utils import fixed_eval_indices
C,ERRORS=load_config(ROOT/'configs/config_v0.yaml',ROOT/'configs/tiny_moe.yaml')


class MasterCLITests(unittest.TestCase):
    def invoke(self,*args):
        return subprocess.run([sys.executable,str(ROOT/'harness/check_config.py'),*map(str,args)],capture_output=True,text=True,encoding='utf8')
    def test_exact_handover_command_zero_and_explicit_waiting(self):
        result=self.invoke(ROOT/'configs/config_v0.yaml');self.assertEqual(result.returncode,0,result.stdout)
        self.assertIn('34 declared pending',result.stdout);self.assertIn('NOT a runnable',result.stdout);self.assertIn('0 errors',result.stdout)
    def test_strict_rejects_unresolved_sizes(self):
        result=self.invoke(ROOT/'configs/config_v0.yaml','--strict');self.assertEqual(result.returncode,1)
        self.assertIn('MISSING_VALUE',result.stdout)
    def test_concrete_override_executable(self):
        result=self.invoke(ROOT/'configs/config_v0.yaml','--override',ROOT/'configs/tiny_moe.yaml','--require-executable')
        self.assertEqual(result.returncode,0,result.stdout);self.assertEqual(result.stdout.strip(),'0 errors')
    def test_pending_mode_still_checks_padding(self):
        s=(ROOT/'configs/config_v0.yaml').read_text().replace('padded_vocab_size: 131072','padded_vocab_size: 131073')
        with tempfile.TemporaryDirectory() as temp:
            path=pathlib.Path(temp)/'bad.yaml';path.write_text(s);self.assertTrue(load_config(path,allow_open=True)[1])
    def test_every_mapping_group_and_setting_has_comment(self):
        import re
        for line in (ROOT/'configs/config_v0.yaml').read_text().splitlines():
            if re.match(r'^\s*[A-Za-z_][A-Za-z_0-9]*:',line):self.assertIn('# source:',line)


class AdoptedRoutingTests(unittest.TestCase):
    def compare(self,device):
        torch.manual_seed(1234);a=copy.deepcopy(C);a['moe']['dropless_moe']=False;a['moe']['dropless']=False;a['moe']['train_capacity_factor']=.5
        b=copy.deepcopy(a);b['moe']['dispatch_impl']='slot_reference'
        dense,slot=MoE(a).to(device),MoE(b).to(device);slot.load_state_dict(dense.state_dict())
        x=torch.randn(2,5,96,device=device,requires_grad=True);y=x.detach().clone().requires_grad_(True)
        valid=torch.tensor([[1,1,1,1,1],[1,1,0,0,0]],device=device,dtype=torch.bool)
        out,aux,z,_=dense(x,valid);other,aux2,z2,_=slot(y,valid)
        torch.testing.assert_close(out,other,atol=1e-6,rtol=1e-5)
        (out.square().sum()+aux+z).backward();(other.square().sum()+aux2+z2).backward()
        torch.testing.assert_close(x.grad,y.grad,atol=1e-6,rtol=1e-5)
        for p,q in zip(dense.parameters(),slot.parameters()):
            self.assertIsNotNone(q.grad);torch.testing.assert_close(p.grad,q.grad,atol=2e-5,rtol=2e-5)
        self.assertTrue(torch.equal(other[~valid],torch.zeros_like(other[~valid])))
    def test_unique_slot_matches_dense_outputs_gradients_cpu(self):self.compare('cpu')
    @unittest.skipUnless(torch.cuda.is_available(),'CUDA unavailable')
    def test_unique_slot_matches_dense_outputs_gradients_cuda(self):
        torch.use_deterministic_algorithms(True);self.compare('cuda')
    def test_sequence_aux_formula_excludes_padding(self):
        c=copy.deepcopy(C);c['moe']['aux_loss_scope']='sequence';c['moe']['scoring_func']='sigmoid'
        moe=MoE(c);x=torch.randn(2,4,96);valid=torch.tensor([[1,1,1,1],[1,0,0,0]],dtype=torch.bool)
        _,aux,_,_=moe(x,valid);scores=moe.router(x).sigmoid();p=scores/scores.sum(-1,keepdim=True)
        top=scores.argsort(dim=-1,descending=True,stable=True)[...,:moe.k]
        selected=top[...,None].eq(torch.arange(len(moe.experts))).any(-2)&valid[...,None]
        length=valid.sum(1);f=selected.sum(1)/(length[:,None]*moe.k);mean=(p*valid[...,None]).sum(1)/length[:,None]
        expected=len(moe.experts)*(f*mean).sum(-1).mean();torch.testing.assert_close(aux,expected)
    def test_router_intervention_zero_without_bias(self):
        moe=MoE(C);_,_,_,stats=moe(torch.randn(1,3,96),torch.ones(1,3,dtype=torch.bool))
        self.assertEqual(stats['moe/router_intervention_rate'],0.)
        self.assertTrue(0<=stats['moe/topk_score_mass']<=1)
        self.assertTrue(0<=stats['moe/router_score_entropy']<=math.log(8)+1e-6)


class MaskedProjectionTests(unittest.TestCase):
    def test_scored_only_projection_matches_full_ignore_index_loss_and_gradients(self):
        import types
        from model import Model
        c={'output':{'loss_chunk_tokens':2},'tokenizer':{'vocab_size':8}}
        weight=torch.randn(8,4,requires_grad=True);x=torch.randn(5,4,requires_grad=True)
        y=torch.tensor([1,-100,2,-100,3]);obj=types.SimpleNamespace(c=c,project_logits=lambda h:torch.nn.functional.linear(h,weight))
        nll,z=Model.losses(obj,x,y);logits=torch.nn.functional.linear(x,weight)
        reference=torch.nn.functional.cross_entropy(logits,y,ignore_index=-100,reduction='sum')
        reference_z=(logits.logsumexp(-1).square()*y.ne(-100)).sum()
        torch.testing.assert_close(nll,reference);torch.testing.assert_close(z,reference_z)
        actual=torch.autograd.grad(nll+.1*z,(x,weight),retain_graph=True)
        expected=torch.autograd.grad(reference+.1*reference_z,(x,weight))
        for a,b in zip(actual,expected):torch.testing.assert_close(a,b,atol=1e-6,rtol=1e-5)
        self.assertTrue(torch.equal(actual[0][y.eq(-100)],torch.zeros_like(actual[0][y.eq(-100)])))


class MonitoringTests(unittest.TestCase):
    def test_warmup_and_state_restore(self):
        c=copy.deepcopy(C['monitoring']);c['warmup_steps']=2
        a=StepMonitor(c);self.assertIsNone(a.observe(1.,1,[])[0]['stability/ema_z'])
        a.observe(1.1,2,[]);b=StepMonitor(c);b.load_state_dict(a.state_dict())
        self.assertEqual(a.observe(1.2,3,[]),b.observe(1.2,3,[]))
        self.assertEqual(a.state_dict(),b.state_dict())
    def test_injected_spike_warns_after_warmup(self):
        c=copy.deepcopy(C['monitoring']);c['warmup_steps']=2;a=StepMonitor(c)
        a.observe(1.,1,[]);a.observe(1.,2,[])
        values,events=a.observe(100.,3,[]);self.assertIn('alarm/loss_spike',events)
        self.assertTrue(math.isfinite(values['stability/loss_spike_score']))
    def test_sustained_imbalance_requires_patience(self):
        c=copy.deepcopy(C['monitoring']);c['imbalance_patience']=2;a=StepMonitor(c);layers=[{'moe/max_load_violation':2.}]
        self.assertNotIn('alarm/sustained_expert_imbalance',a.observe(1.,1,layers)[1])
        self.assertIn('alarm/sustained_expert_imbalance',a.observe(1.,2,layers)[1])
    def test_fixed_eval_includes_each_available_slice_without_rng(self):
        import types
        corpus=types.SimpleNamespace(slice_by_offset={0:'a',1:'a',2:'b'})
        windows=types.SimpleNamespace(windows=[(0,0,4),(0,4,4),(1,0,4),(2,0,4)],corpus=corpus)
        state=torch.get_rng_state().clone();indices=fixed_eval_indices(windows,['a','b'],3)
        self.assertEqual(indices,[0,3,1]);self.assertTrue(torch.equal(state,torch.get_rng_state()))

if __name__=='__main__':unittest.main()
