"""Fresh-process G5 seed gate; inspired by Deepjyoti Saha seed_test.py.

Default: python harness/seed_test.py --device cpu --out evidence/my_gate
The bundled fixture is a wiring/optimization test, not language-quality evidence.
"""
import argparse,json,pathlib,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--out',type=pathlib.Path,default=ROOT/'evidence/seed_gate');p.add_argument('--seed',type=int,default=1234)
    p.add_argument('--negative-control',action='store_true');a=p.parse_args()
    for name,seed in [('run_a',a.seed),('run_b',a.seed)]+([('control',a.seed+1)] if a.negative_control else []):
        subprocess.run([sys.executable,str(ROOT/'harness/train.py'),'--seed',str(seed),'--device',a.device,'--out',str(a.out/name)],check=True)
    for name in ['loss.txt','total_loss.txt','loss_hex.txt']:
        if (a.out/'run_a'/name).read_bytes()!=(a.out/'run_b'/name).read_bytes():raise SystemExit('FAIL: '+name+' differs')
    summaries=[json.loads((a.out/n/'summary.json').read_text()) for n in ['run_a','run_b']]
    assert all(s['nan_count']==0 and s['every_train_step_decreased'] and s['status']=='PASS' for s in summaries)
    assert summaries[0]['final_model_sha256']==summaries[1]['final_model_sha256']
    if a.negative_control:assert (a.out/'control/loss.txt').read_bytes()!=(a.out/'run_a/loss.txt').read_bytes()
    print('PASS: empty decimal/hex CE and total-loss diff; strictly decreasing fixture CE; zero NaNs; final weights identical')

if __name__=='__main__':main()
