"""Static typed schema and parent source compliance before numerical validation."""
import json,math,pathlib
import yaml
from source_audit import audit_text
ROOT=pathlib.Path(__file__).resolve().parent

def preflight(path,override=None):
    errors=[];kinds=json.loads((ROOT/'schema_types.json').read_text())
    pending=set(json.loads((ROOT/'pending_size_fields.json').read_text()))
    def walk(obj,prefix=''):
        for key,value in obj.items():
            name=prefix+'.'+key if prefix else key
            if isinstance(value,dict):yield from walk(value,name)
            else:yield name,value
    for file in [path]+([override] if override else []):
        text=pathlib.Path(file).read_text(encoding='utf-8-sig')
        for row in audit_text(text,include_containers=True):
            for issue in row['issues']:
                if issue!='MISSING_VALUE':errors.append(row['setting']+': '+issue+' in '+pathlib.Path(file).name)
        obj=yaml.safe_load(text)
        for name,value in walk(obj):
            if name not in kinds:
                errors.append(name+': unknown schema field');continue
            if value is None:
                if name not in pending:errors.append(name+': null is not a declared open size')
                continue
            kind=kinds[name]
            scalar=lambda v:type(v) in (int,float) and math.isfinite(v)
            ok=(type(value)is bool if kind=='bool' else type(value)is int if kind=='int' else scalar(value) if kind=='number' else type(value)is str and bool(value.strip()) if kind=='str' else isinstance(value,list) and bool(value) and all(type(v)is str and bool(v.strip()) for v in value) if kind=='list_str' else isinstance(value,list) and bool(value) and all(scalar(v) for v in value))
            if not ok:errors.append(name+': expected '+kind)
    return errors
