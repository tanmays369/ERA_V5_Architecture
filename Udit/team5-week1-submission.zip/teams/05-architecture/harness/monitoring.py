"""Deterministic warm-started diagnostics, adapted from Revant Gupta 9aa4fcf.

Z-scores are diagnostics, not calibrated anomaly probabilities. No RNG is used.
All temporal state is checkpointed. Warnings do not replace G8's logger/alarms.
"""
import math


class StepMonitor:
    def __init__(self,config):
        self.config=config;self.history=[];self.ema=None;self.variance=0.;self.imbalance_streak=0
    def observe(self,loss,step,layers):
        c=self.config
        if not c['enabled']:return {},[]
        ready=len(self.history)>=c['warmup_steps']
        if ready:
            mean=sum(self.history)/len(self.history);variance=sum((v-mean)**2 for v in self.history)/len(self.history)
            spike=(loss-mean)/max(math.sqrt(variance),1e-12)
        else:spike=None
        if self.ema is None:self.ema=loss
        delta=loss-self.ema;alpha=c['ema_alpha']
        self.ema=alpha*self.ema+(1-alpha)*loss
        self.variance=alpha*self.variance+(1-alpha)*delta*delta
        ema_z=(loss-self.ema)/max(math.sqrt(self.variance),1e-12) if ready else None
        maxvio=max((layer.get('moe/max_load_violation',0.) for layer in layers),default=0.)
        self.imbalance_streak=self.imbalance_streak+1 if maxvio>c['max_load_violation'] else 0
        maxlogit=max((layer.get('attention/max_abs_logit',0.) for layer in layers),default=0.)
        events=[]
        if spike is not None and spike>c['spike_sigma']:events.append('alarm/loss_spike')
        if ema_z is not None and ema_z>c['ema_z_threshold']:events.append('alarm/ema_deviation')
        if maxlogit>c['max_attn_logit']:events.append('alarm/attention_logit')
        if self.imbalance_streak>=c['imbalance_patience']:events.append('alarm/sustained_expert_imbalance')
        self.history.append(loss);self.history=self.history[-c['history_window']:]
        return {'stability/loss_spike_score':spike,'stability/ema_z':ema_z,
                'stability/imbalance_streak':self.imbalance_streak},events
    def state_dict(self):
        return dict(history=self.history[:],ema=self.ema,variance=self.variance,imbalance_streak=self.imbalance_streak)
    def load_state_dict(self,state):
        for key,value in state.items():setattr(self,key,value)
