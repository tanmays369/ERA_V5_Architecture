# Unified G5 -> G8 metrics and alarms contract

Canonical math and aliases are explicit. JSONL flushes every training.flush_every (default10) updates. Step numbering starts at1. This single-process FP32 reference logs exact scored targets; timings and memory are observations, excluded from bitwise numerical comparisons. The external G8 logger/3000-value alarm integration remains pending.

## Step-level fields

| Name | Definition / unit | Cadence |
|---|---|---|
| loss/ce; train/ce_loss; train/ce | Summed FP32 cross-entropy / valid target tokens, nats/token | every update |
| loss/total; train/total_loss | CE + scheduled aux coefficient*raw aux + router_z coefficient*raw router z + logit z coefficient*raw logit z + MTP coefficient*raw MTP | every update |
| loss/moe_aux; loss/router_z; loss/logit_z; loss/mtp | Raw, unweighted auxiliary quantities; MTP=0 when no heads. Loss coefficients are in the resolved config | every update |
| train/perplexity; train/token_perplexity | exp(train CE), excludes all auxiliary losses | every update |
| train/bpb | Total CE NLL / (ln2 * exact bytes represented by scored content targets) | every update |
| train/valid_tokens; train/raw_utf8_bytes | Actual scored tokens and exact target bytes; PAD/BOS/EOS structural positions excluded by this objective | every update |
| stability/grad_norm_preclip; stability/clipped | Gradient norm before clipping and whether it exceeded the configured threshold | every update |
| optimizer/adamw_lr; optimizer/muon_lr; optimizer/wsd_factor | Applied group-base schedule values; per-role multipliers in manifest optimizer_groups | every update |
| perf/step_seconds; perf/tokens_per_second | Reference core training-step time and valid targets / seconds; excludes validation/checkpoint I/O and post-step monitor/update-ratio reductions | every update |
| curriculum/stage; curriculum/seq_len; curriculum/rope_theta; curriculum/moe_aux_loss_coeff; curriculum/router_temperature; curriculum/transition_progress | Active stage and interpolated controls | every update |
| curriculum/tokens_per_step; curriculum/tokens_seen; curriculum/grad_accum_steps | Exact valid-target budget, cumulative total and actual microbatch count | every update |
| curriculum/mixture_weights; curriculum/observed_tokens_per_slice | Sampling probabilities and observed scored tokens; probabilities need not equal token fractions | every update |
| data/window_indices; data/batch_sha256 | Deterministic sampled windows and SHA256 of scored target arrays | every update |
| stability/loss_spike_score; stability/ema_z | Prior-history and EMA z-scores, null until monitoring warmup is populated. Diagnostic values, not calibrated probabilities | every update when monitoring enabled |
| stability/imbalance_streak | Consecutive updates with any layer above monitoring.max_load_violation | every update |
| stability/update_to_weight_ratio | sqrt(sum(delta_parameter^2)/sum(parameter_before^2)), all parameters | XAI telemetry cadence |

Agreed simple aliases: **loss** = loss/total; **loss_ntp** = loss/ce; **loss_mtp** = loss/mtp (raw, 0 if disabled); **lr** = optimizer/adamw_lr; **tokens_per_second** = perf/tokens_per_second; **gpu_alloc_gb** = current CUDA allocated bytes/1e9, 0 on CPU. gpu_alloc_gb is decimal GB, not GiB, peak or allocator reservation. These aliases reconcile Shivanshu/Deepjyoti/Revant naming; original submissions sometimes used different meanings/units, so do not mix them silently.

## Fixed held-out evaluation

`val/perplexity`, `val/bpb`, `validation/ce`, `validation/bpb`, and eval/ce, eval/perplexity, eval/bpb aliases all describe held-out CE-only evaluation under eval()+no_grad(). They are not training perplexity. Probe/* measures fixed training documents and must not be relabeled validation.

`val/by_slice` maps arbitrary configured slice IDs to {ce,bpb,perplexity,tokens,bytes}. `val/macro_bpb` is their arithmetic BPB mean; `val/missing_slices` explicitly lists absent slices. Global val/bpb is NLL-sum / byte-sum and therefore byte-weighted; equal window counts do NOT make it an equal-source mean. The fixed round-robin window selection is independent of run seed. Summary initial/final evaluation includes raw token/byte totals. EOS prediction is a separate pending long-run objective decision.

## Per-layer fields in layers[index]

| Name | Definition |
|---|---|
| moe/expert_counts | Kept routed slot counts across all microbatches; excludes masked/PAD and shared-expert execution |
| moe/utilization_entropy; explain/expert_utilization_entropy | Entropy of normalized kept expert slot counts / ln(E); 0..1 for nonempty dropless loads |
| moe/max_load_violation; explain/max_load_violation | max kept count / (valid targets*k/E) - 1 |
| moe/dead_expert_count; explain/dead_expert_count | Experts unused in this populated update. Does not mean permanently dead |
| moe/dropped_token_ratio; moe/dropped_slot_ratio | Valid targets losing all routed slots; requested slots dropped by capacity |
| moe/router_bias_max_abs | Max absolute detached selection bias |
| moe/shared_expert_norm_ratio | ||shared output|| / (||routed output||+epsilon) |
| moe/router_z_loss; explain/router_z | FP32 mean square logsumexp(router logits) |
| moe/router_score_entropy | Mean entropy in nats of normalized router scores, distinct from utilization entropy |
| moe/router_intervention_rate | Fraction of selected slots differing from unbiased ungrouped top-k; includes group filtering when enabled, so not solely bias in grouped mode |
| moe/topk_score_mass | Mean normalized unbiased score mass assigned to requested top-k, before capacity dropping |
| residual/l2_mean; explain/residual_l2 | Mean valid-token output residual L2 norm |
| residual/input_output_cosine; explain/residual_cosine | cos(block input, block output), valid-token mean |
| attention/entropy_per_head; explain/attention_entropy_per_head | Shannon attention entropy per query head in nats. Differential reference reports mean entropy of its two positive softmax maps, not entropy of signed difference |
| attention/max_abs_logit | Sampled max absolute scaled attention logits at telemetry updates, before softcap and excluding masked/padded pairs |
| attn/qk_norm_scale | RMS query magnitude after QK norm and RoPE; not the learned norm-gain parameter itself |
| attn/kv_cache_bytes_per_token | Per-layer FP32 payload estimate; excludes allocator/metadata and shared/sink accounting overhead |
| attn/is_local; attn/effective_kv_heads; attn/context_extension_ratio; attn/sink_mass | Local/global indicator, effective KV heads, observed positions/original context ratio, optional sink mass |
| logit_lens/ce; explain/logit_lens_ce; explain/logit_lens_kl | Final-norm/head intermediate CE and KL(final distribution || intermediate distribution), detached readout |
| explain/sae | List by tap_point; reconstruction_mse, feature_l0, dead_feature_count/fraction and observation_count, with explain/sae_ prefixes |

Residual/attention telemetry follows tap_every_steps (plus step1); lens follows logit_lens_every_steps (plus step1). Router statistics are always available when configured, while explain/* aliases disappear when XAI is off. SAE list metrics describe the most recent captured microbatch; do not present them as already-aggregated update/global feature statistics. The random Top-K mode is an untrained plumbing baseline. Hooks pass detached cloned tensors and isolate Python/NumPy/CPU/CUDA RNGs. No external XAI dependency is used.

## Events and checkpoints

| Event | Action / provisional rule |
|---|---|
| alarm/nonfinite_loss, alarm/nonfinite_activation, alarm/nonfinite_gradient, alarm/nonfinite_parameter | Fatal; stop before further updates/checkpoint contamination. Actual fail paths exercised by integration tests |
| alarm/loss_spike | Diagnostic warning after warmup when prior-history z > monitoring.spike_sigma (7 by default) |
| alarm/ema_deviation | Diagnostic warning after warmup when EMA z > monitoring.ema_z_threshold (2.5 by default) |
| alarm/attention_logit | Diagnostic warning when sampled magnitude > monitoring.max_attn_logit (100 by default) |
| alarm/sustained_expert_imbalance | Diagnostic warning only after imbalance_patience populated updates above MaxVio threshold |
| alarm/sae_dead_features | Probe diagnostic after a full per-tap observation window; threshold requires trained-probe/G8 calibration |

No rule declares every transient unused expert a permanent collapse. Nonfinite checks operate every update; sampled attention magnitude cannot detect an unsampled transient. Test temporal detectors with G8's synthetic stream before operational use.

Checkpoint contains model/buffers, optimizer groups/state, WSD scheduler, curriculum and mixture state, monitor history/EMA/streak, sampler permutation/cursors/generator, Python/NumPy/CPU/CUDA RNG, probe history and strict code/config/data/tokenizer/environment provenance. Stop/resume preserves the original total schedule. Decimal and hex CE/total-loss traces and final state hashes must match same-environment uninterrupted execution. Component/communication/checkpoint-save timing remains G6's contract; step timing here is not end-to-end GPU cost.

## Reversibility: future measurements, not currently emitted

REV-1 reserves reconstruction/gradient relative and absolute error, activation-memory bytes and recompute time for G6/G8 agreement. The current engine emits no reversible-runtime measurements because it is disabled and unimplemented. Do not infer reconstruction success or memory saving from activation_checkpointing=true. Router counts/bias updates and XAI observations must not be duplicated by any future recompute pass.
