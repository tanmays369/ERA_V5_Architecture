# Submitted run results

These are verification-fixture results, not completed real-data architecture ablations. The experiment plan is in experiments/plan_v0.md.

| Device | Steps | First CE | Last CE | NaNs | Repeat / resume / XAI |
|---|---:|---:|---:|---:|---|
| cpu | 30 | 11.6967671712 | 9.5383699205 | 0 | Byte-identical loss traces and final state hashes |
| cuda | 30 | 11.6967671712 | 9.5383614434 | 0 | Byte-identical loss traces and final state hashes |

Full test result:104 passed,0 skipped. CPU and CUDA are compared within their own environment; cross-device bitwise identity is not required.

Large checkpoints, token caches, duplicate historical evidence, forensic inventories and the separate Kaggle submission are excluded.