"""Write experiment overrides OUTSIDE the immutable training source tree."""
import argparse,copy,pathlib,yaml


def write(path,c):
    text=yaml.safe_dump(c,sort_keys=False,allow_unicode=True)
    text='\n'.join(line+'  # source: G5 explicit XAI/1000-step verification experiment, 26 Oct; not TSAI production approval' for line in text.splitlines())+'\n'
    path.write_text(text,encoding='utf8')


def make(root,out):
    root,out=pathlib.Path(root),pathlib.Path(out);out.mkdir(parents=True,exist_ok=True)
    if out.resolve().is_relative_to(root.resolve()):raise ValueError('Keep new configs outside training ROOT to preserve old checkpoint source hashes')
    base=yaml.safe_load((root/'configs/kaggle_100m.yaml').read_text())
    on=copy.deepcopy(base);on['training'].update(steps=1000,warmup_steps=100)
    on.setdefault('data',{}).update(mode='deterministic_slice',slice_documents=64)
    on['evaluation'].update(eval_every_steps=2,eval_batches=2)
    on['explainability'].update(enabled=True,enable_logit_lens=True,tap_every_steps=2,logit_lens_every_steps=2)
    on['explainability']['sae_probe']=dict(enabled=True,kind='random_topk_reference')
    on['checkpointing'].update(save_every_steps=2,keep_last_n=2)
    off=copy.deepcopy(on);off['explainability']['enabled']=False
    main=copy.deepcopy(on);main['data'].update(mode='full')
    main['evaluation'].update(eval_every_steps=50,eval_batches=32)
    main['explainability'].update(tap_every_steps=50,logit_lens_every_steps=200)
    main['checkpointing'].update(save_every_steps=100,keep_last_n=2)
    main['data_curriculum']['transition_ramp_steps']=20
    for name,c in [('xai_on.yaml',on),('xai_off.yaml',off),('xai_1000_full_data.yaml',main)]:write(out/name,c)
    print('Wrote configs:',out)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();make(a.root,a.out)
