"""Audit saved DDP records and optional local checkpoint. Does not train."""
import argparse,hashlib,json,math,pathlib,statistics


def finite(value):
    if isinstance(value,dict):return all(finite(v) for v in value.values())
    if isinstance(value,list):return all(finite(v) for v in value)
    return not isinstance(value,float) or math.isfinite(value)


def audit(root,checkpoint=False):
    root=pathlib.Path(root);manifest=json.loads((root/'manifest.json').read_text())
    summary=json.loads((root/'summary.json').read_text())
    rows=[json.loads(line) for line in (root/'metrics.jsonl').read_text().splitlines()]
    c=manifest['config'];world=manifest['world_size'];expected=c['data_curriculum']['global_tokens_per_step'];k=c['moe']['num_experts_per_tok']
    assert rows and len(rows)==summary['completed_steps']
    assert [r['step'] for r in rows]==list(range(1,len(rows)+1))
    assert finite(rows) and finite(summary),'Nonfinite record'
    assert summary['nan_count']==0 and summary['rank_models_identical']
    assert not (root/'alarms.jsonl').read_text().strip(),'Recorded alarms'
    keys=['explain/residual_cosine','explain/residual_l2','explain/attention_entropy_per_head','explain/logit_lens_kl']
    coverage={key:[] for key in keys};sae_steps=[];global_entropies=[];global_unused=[];max_global_overloads=[]
    for row in rows:
        assert row['train/valid_tokens']==expected
        assert math.isclose(row['train/perplexity'],math.exp(row['loss/ce']),rel_tol=1e-12)
        assert math.isclose(row['train/bpb'],row['loss/ce']*expected/(math.log(2)*row['train/raw_utf8_bytes']),rel_tol=1e-10)
        if 'val/ce_loss' in row:
            assert math.isclose(row['val/perplexity'],math.exp(row['val/ce_loss']),rel_tol=1e-12)
            assert row['val/bpb']>0
        ranks=row['ranks'];assert len(ranks)==world
        for i in range(world):
            for j in range(i):assert not set(ranks[i]['window_indices'])&set(ranks[j]['window_indices'])
        for key in keys:
            if any(key in layer for rank in ranks for layer in rank['layers']):coverage[key].append(row['step'])
        if any(layer.get('explain/sae') for rank in ranks for layer in rank['layers']):sae_steps.append(row['step'])
        for layer_index in range(c['model']['num_layers']):
            counts=[0.]*c['moe']['num_experts']
            for rank in ranks:
                layer=rank['layers'][layer_index]
                if 'explain/residual_cosine' in layer:assert -1.000001<=layer['explain/residual_cosine']<=1.000001
                if 'explain/attention_entropy_per_head' in layer:
                    assert len(layer['explain/attention_entropy_per_head'])==c['attention']['query_heads']
                    assert all(-1e-6<=v<=math.log(c['training']['sequence_length'])+1e-5 for v in layer['explain/attention_entropy_per_head'])
                for probe in layer.get('explain/sae',[]):
                    assert 0<=probe['explain/sae_feature_l0']<=c['explainability']['sae_probe']['top_k']
                    assert probe['explain/sae_reconstruction_mse']>=0
                    assert 0<=probe['explain/sae_dead_feature_fraction']<=1
                if 'moe/expert_counts' not in layer:continue
                assert layer['moe/dropped_token_ratio']==0,'Dropped tokens in dropless pilot'
                assert math.isclose(sum(layer['moe/expert_counts']),rank['local_tokens']*k)
                counts=[a+b for a,b in zip(counts,layer['moe/expert_counts'])]
            total=sum(counts)
            if total:
                p=[v/total for v in counts]
                global_entropies.append(-sum(v*math.log(v) for v in p if v)/math.log(len(p)))
                global_unused.append(sum(v==0 for v in counts))
                max_global_overloads.append(max(counts)/(total/len(counts))-1)
    report=dict(status='PASS',steps=len(rows),parameters=manifest['parameters'],world_size=world,
                metrics_finite=True,ppl_formula_verified=True,train_bpb_formula_verified=True,
                validation_bpb_note='Val NLL/bytes are not logged per event; final values are in summary, so raw-byte formula cannot be independently reconstructed for every val event',
                disjoint_rank_windows=True,global_tokens_per_step=expected,nan_count=0,
                rank_model_states_identical=summary['rank_models_identical'],xai_step_coverage=coverage,sae_step_coverage=sae_steps,
                global_expert_entropy_min=min(global_entropies),global_expert_entropy_mean=statistics.mean(global_entropies),
                globally_unused_experts_in_one_layer_update_max=max(global_unused),
                global_max_load_violation_max=max(max_global_overloads),
                peak_pytorch_allocated_gib=max(r['memory/max_allocated_bytes_per_rank'] for r in rows)/2**30,
                training_documents=manifest['train_documents'],validation_documents=manifest['validation_documents'],
                final_validation=summary['final_validation'],
                sae_note='Random Top-K probe only checks hook/reconstruction/sparsity plumbing; no trained SAE features or calibrated collapse diagnosis')
    v=summary['final_validation']
    assert math.isclose(v['bpb'],v['ce']*v['tokens']/(math.log(2)*v['bytes']),rel_tol=1e-10)
    report['final_validation_bpb_formula_verified']=True
    if checkpoint:
        import torch
        path=root/'checkpoint.pt';state=torch.load(path,map_location='cpu',weights_only=True,mmap=True)
        for key in ['model','optimizers','scheduler','curriculum','rank_states','records','identity','active_stage']:assert key in state,key
        assert state['step']==summary['completed_steps']==state['scheduler']['step']==state['curriculum']['step']
        assert state['curriculum']['tokens_seen']==len(rows)*expected
        assert len(state['rank_states'])==world
        assert len(list(root.glob('checkpoint_step_*.pt')))<=c['checkpointing']['keep_last_n']
        for local in state['rank_states']:
            assert all(key in local['sampler'] for key in ['generator','orders','positions'])
            assert all(key in local['rng'] for key in ['python','numpy','cpu','cuda'])
        assert len(state['optimizers'])==len(manifest['optimizer_groups']['optimizer_order'])
        digest=hashlib.sha256()
        for name,value in sorted(state['model'].items()):digest.update(name.encode());digest.update(value.contiguous().numpy().tobytes())
        assert digest.hexdigest()==summary['final_model_sha256'],'Checkpoint weights differ from final summary'
        report['checkpoint']=dict(status='PASS',step=state['step'],bytes=path.stat().st_size,
             complete_optimizer_scheduler_curriculum_sampler_rng=True,model_hash_matches_final_summary=True,
             numbered_checkpoints=len(list(root.glob('checkpoint_step_*.pt'))),
             retention_limit=c['checkpointing']['keep_last_n'])
    (root/'audit_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2));return report


def compare(a,b):
    a,b=pathlib.Path(a),pathlib.Path(b)
    for name in ['loss.txt','total_loss.txt']:assert (a/name).read_bytes()==(b/name).read_bytes(),name+' differs'
    sa,sb=[json.loads((p/'summary.json').read_text()) for p in [a,b]]
    assert sa['final_model_sha256']==sb['final_model_sha256'],'Final model states differ'
    records=[[json.loads(l) for l in (p/'metrics.jsonl').read_text().splitlines()] for p in [a,b]]
    def batches(rows):return [[(r['rank'],r['batch_sha256'],r['window_indices']) for r in row['ranks']] for row in rows]
    assert batches(records[0])==batches(records[1]),'Data batches differ'
    print('PASS: CE + total-loss EMPTY DIFF; final model hashes and rank batches identical')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('run');p.add_argument('--checkpoint',action='store_true');p.add_argument('--compare')
    a=p.parse_args()
    if a.compare:compare(a.run,a.compare)
    else:audit(a.run,a.checkpoint)
